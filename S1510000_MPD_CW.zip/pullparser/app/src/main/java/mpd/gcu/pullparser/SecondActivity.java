package mpd.gcu.pullparser;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
TextView text;
TextView t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        text =(TextView) findViewById(R.id.textInfo);

        Bundle bundle = getIntent().getExtras();
        text.setText(bundle.getString("Earthquake"));
    }
}
