package mpd.gcu.pullparser;

public class Earthquake {
    private String title;
    private String description;
    private String link;
    private String pubDate;
    private String category;
    private String geolat;
    private String geolong;
    private String magnitude;
    private String depth;


    public Earthquake() {
        title = "";
        description = "";
        link = "";
        pubDate = "";
        category = "";
        geolat = "";
        geolong = "";
        magnitude="";
        depth = "";

    }

    public Earthquake(String etitle) {

        title = etitle;
    }

    public void setGeolong(String egeolong) {
        geolong = egeolong;
    }

    public String getGeolong() {
        return geolong;
    }

    public void setGeolat(String egeolat) {
        geolat = egeolat;
    }

    public String getGeolat() {
        return geolat;
    }

    public void setCategory(String ecategory) {
        category = ecategory;
    }

    public String getCategory() {
        return category;
    }

    public void setPubDate(String epubDate) {
        pubDate = epubDate;
    }

    public String getPubDate() {
        return pubDate;
    }

    public void setLink(String elink) {
        link = elink;
    }

    public String getLink() {
        return link;
    }

    public void setTitle(String etitle) {
        title = etitle;
    }

    public String getTitle() {
        return title;
    }

    public void setDescription(String edescription) {
        description = edescription;
    }

    public String getDescription() {
        return description;
    }

    public String toString2() {
        String temp;
        String[] q = getTitle().split(",");
        temp = "Location: " + q[0]+  "\n"
                + "Magnitude: " + getMagnitude() + "\n"
                + "Date: " + getPubDate();

        return temp;
    }
public void setMagnitude(String emagnitude) { magnitude = emagnitude; }
public String getMagnitude(){return magnitude;}

    public void setDepth(String edepth){depth = edepth;}
    public String getDepth() {return depth;}

    public String toString()
    {
    String temp;
    temp= getTitle()+ "\n"+
           getPubDate() +
            "\n" + "Depth: "+ getDepth() + "\n" + "Magnitude: "+ getMagnitude() + "\n" + "Date: "+ getPubDate();

        return temp;
    }

}





