package mpd.gcu.pullparser;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import java.util.List;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.LinkedList;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    //DATA CREDIT:Contains British Geological Survey materials ©NERC 2019
    ListView simpleList;
   private TextView textDisplay;
    LinkedList <Earthquake> alist;
    private Button startButton;
    private String result = "";
    private String url1="";
    private String urlSource="http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";
    Button search;
    Button se;
    private Date startDate;
    private Date endDate;
  //  private EarthquakeAdapter arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
// Set Layouts

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        search = (Button)findViewById(R.id.search);
        se = (Button)findViewById(R.id.btn2);
//Start project
startProgress();



    }
    //Uneeded
    public void onClick(View aview)
    {
        startProgress();

    }
    //Create thread and start URL stuff
    public void startProgress()
    {
        // Run network access on a separate thread;
        new Thread(new Task(urlSource)).start();
    }


//Parse method takes the stuff you want parsed.
    private LinkedList<Earthquake> parseData(String dataToParse)
    {
   //     //Set up booleans to skip 2 instances of title and 1 of description
        Earthquake quake = null;
        boolean firstTitle1= true;
        boolean firstTitle2= false;
        boolean firstDescription = true;


         LinkedList<Earthquake> alist = null;
      //xml pullparser code given by labs
        try
        {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput( new StringReader( dataToParse ) );
            int eventType = xpp.getEventType();
          //  Log.e("progress","You get to here");

            //Create new List
            alist  = new LinkedList<Earthquake>();
            while (eventType != XmlPullParser.END_DOCUMENT)
            {
               // Look for start Tags

                // Found a start tag
                if(eventType == XmlPullParser.START_TAG)
                {
                // Look for Item
                    if (xpp.getName().equalsIgnoreCase("item"))
                    {
                    //Create New EarthQuake
                        Log.e("MyTag","Item Start Tag found");
                        quake = new Earthquake();
                    }
                    else
                        if (xpp.getName().equalsIgnoreCase("title"))
                        {

                            if (firstTitle1 == true)
                            {

                                firstTitle1 = false;
                                firstTitle2 = true;
                            }
                            else
                                if (firstTitle2 == true)
                                {
                                    firstTitle2 = false;
                                }
                            else
                            {
                                //After ignoring first 2 times....
                                String temp = xpp.nextText();
                                // Do something with text
                               // Log.e("MyTag","title is " + temp);

                            }
                        }
                    else
                        // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("description"))
                        {
                            if(firstDescription == true)
                            {
                                firstDescription = false;
                            }
                            else {
                                // After ignoring 1 time.....
                                //Also the description has everything I need seperated by a ';'
                                String temp = xpp.nextText();
                                // Array setup starts
                                String[] arr = temp.split(";");
                                String t;
                                String m;
                                String d;
                                String dt;
                                String[] a = temp.split(":");
                                //Really this next part is just so its not all in capitals
                                 t = arr[1].substring(11,12)+ arr[1].substring(12).toLowerCase();
                                d = arr[arr.length-2].substring(7);
                                m = a[a.length-1];
                                dt = arr[0].substring(18);
                                // Set all the stuff
                                quake.setPubDate(dt);
                                quake.setTitle(t);
                                quake.setDepth(d);
                                quake.setMagnitude(m);
                               // Log.e("MyTag", "description is " + temp);
                                quake.setDescription(temp);
                            }
                        }

                            // Check which Tag we have

                }
                else
                if(eventType == XmlPullParser.END_TAG)
                {
                    if (xpp.getName().equalsIgnoreCase("item"))
                    {
                      //  Add the EarthQuake to the list.
                        alist.add(quake);

                        Log.e("MyTag","List is  " + alist.size());
                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("channel"))
                    {
                        int size;
                        // It said size() was compulsory.
                        size = alist.size();
                        Log.e("MyTag","Earthquake size is " + size);
                    }
                }


                // Get the next event
                eventType = xpp.next();

            } // End of while



           // return alist;


        }
        catch (XmlPullParserException ae1)
        {
            Log.e("MyTag","Parsing error" + ae1.toString());
        }
        catch (IOException ae1)
        {
            Log.e("MyTag","IO error during parsing");
        }

        Log.e("MyTag","End document");



        return alist;


    }
    private class Task implements Runnable
    {
        private String url;

        public Task(String aurl)
        {
            url = aurl;
        }
        @Override
        public void run()
        {

            URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";


            // This is from the starter code

            try{
                aurl = new URL(url);
                yc = aurl.openConnection();
//Log.e("url",aurl.toString());
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
                //

                while ((inputLine = in.readLine()) != null)
                {
                    result = result + inputLine;
                  //   Log.e("MyTag",inputLine);

                }


                in.close();
            }
            catch (IOException ae)
            {
                Log.e("MyTag", "ioexception at load");
            }


           // Log.e("data", "parse" + parseData(result));
            //
            // Now that you have the xml data you can parse it

           alist =  parseData(result);

            // After parse return alist for array adapter
            MainActivity.this.runOnUiThread(new Runnable()
            {
                public void run() {
                    Log.d("UI thread", "I am the UI thread");
                 //  Log.e("array", alist.toString());


                    // set up listview, set up array adapter and set the listener for each item in the list
                   simpleList = (ListView)findViewById(R.id.simpleListView);

           //   ArrayAdapter<Earthquake> arrayAdapter
              //         = new ArrayAdapter<Earthquake>(getApplicationContext(), R.layout.activity_list,R.id.text, alist);
                    EarthquakeAdapter arrayAdapter = new EarthquakeAdapter(getApplicationContext(),alist);
                    //custom arrayadapter

                 simpleList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                     @Override
                     public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                         Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                       //  Log.e("title", simpleList.getItemAtPosition(position).toString());

                         intent.putExtra("Earthquake", simpleList.getItemAtPosition(position).toString());
                         startActivity(intent);
                     }
                 });
                 simpleList.setAdapter(arrayAdapter);
                 // set the adapter and below set up the onclick for the buttons
                search.setOnClickListener(new View.OnClickListener() {
                     @Override
                     public void onClick(View v) {
                         final Calendar cldr = Calendar.getInstance();
                         int day = cldr.get(Calendar.DAY_OF_MONTH);
                         int month = cldr.get(Calendar.MONTH);
                         int year = cldr.get(Calendar.YEAR);
                         // date picker dialog
                         DatePickerDialog picker = new DatePickerDialog(MainActivity.this,
                                 new DatePickerDialog.OnDateSetListener() {
                                     @Override
                                     public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                         startDate = new Date();
                                         startDate.setDate(dayOfMonth);
                                         startDate.setMonth(monthOfYear);
                                         startDate.setYear(year-1900);
                                         startDate.setHours(0);
                                         startDate.setMinutes(0);
                                         startDate.setSeconds(0);
                                       //  sets up the startdate
                                     }
                                 }, year, month, day);
                         picker.show();
                     }
                 });
                se.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final Calendar cldr = Calendar.getInstance();
                        int day = cldr.get(Calendar.DAY_OF_MONTH);
                        int month = cldr.get(Calendar.MONTH);
                        int year = cldr.get(Calendar.YEAR);
                        // date picker dialog
                       DatePickerDialog pick = new DatePickerDialog(MainActivity.this,
                                new DatePickerDialog.OnDateSetListener() {
                                    @Override
                                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                        endDate = new Date();
                                        endDate.setDate(dayOfMonth);
                                        endDate.setMonth(monthOfYear);
                                        endDate.setYear(year-1900);
                                        endDate.setHours(23);
                                        endDate.setMinutes(59);
                                        endDate.setSeconds(59);
                                 //       sets up the end date

                                        DateFormat dateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss");
                                        LinkedList<Earthquake> filter = new LinkedList<Earthquake>();
                                        for (Earthquake curEq:alist)
                                        {
                                            Earthquake earth = curEq;
                                            Date d = null;
                                            try
                                            {
                                                d = dateFormat.parse(curEq.getPubDate());
                                  //    Log.e("hi ", d.toString());

                                            }catch (ParseException parseE)
                                            {
                                                parseE.printStackTrace();
                                            }
                                            if(d.after(startDate)&& d.before(endDate))
                                            {
                                                //the actual filter part
                                                filter.add(curEq);
                                            }
                                        }
                                        if(filter.size()!=0)
                                        {

                                            EarthquakeAdapter array= new EarthquakeAdapter(MainActivity.this, filter);
                                            simpleList.setAdapter(array);
                                        }
                                    }
                                }, year, month, day);
                        pick.show();

                    }
                });
                }

            });

        }

    }

}