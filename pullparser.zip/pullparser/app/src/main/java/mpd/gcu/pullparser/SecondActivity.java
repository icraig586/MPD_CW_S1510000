package mpd.gcu.pullparser;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
TextView text;
TextView t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
// set text view up
        text =(TextView) findViewById(R.id.textInfo);
//use bundle to get stuff
        Bundle bundle = getIntent().getExtras();
        // get the toString() of the clicked earthquake using the key set up in MainActivity
        text.setText(bundle.getString("Earthquake"));
    }
}
